-- -----------------------------
-- SentCMS MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : baoxian
-- 
-- Part : #1
-- Date : 2017-07-16 10:34:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `bx_admin`
-- -----------------------------
DROP TABLE IF EXISTS `bx_admin`;
CREATE TABLE `bx_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `bx_admin`
-- -----------------------------
INSERT INTO `bx_admin` VALUES ('1', 'admin', '89b95f3fe7d28a0d91568afb59a24dab', 'admin@admin.com', '', '1499781249', '2130706433', '1500169201', '2130706433', '1499781249', '1');
INSERT INTO `bx_admin` VALUES ('2', 'zhengqi', '066d88bfc70d2d5d5aa66313658bc115', '789@123.com', '', '1499850610', '2130706433', '1500172167', '2130706433', '1499850610', '1');
INSERT INTO `bx_admin` VALUES ('3', 'wangquan', 'd9bd6c85995343d24f55442eac364c06', 'wangquan@qq.com', '', '1500111885', '2130706433', '0', '0', '1500111885', '1');
