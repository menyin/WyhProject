-- -----------------------------
-- SentCMS MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : baoxian
-- 
-- Part : #1
-- Date : 2017-07-28 23:37:35
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `bx_ advertisement`
-- -----------------------------
DROP TABLE IF EXISTS `bx_ advertisement`;
CREATE TABLE `bx_ advertisement` (
  `ad_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `memo` varchar(255) NOT NULL DEFAULT '' COMMENT '位置说明',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1:代理人 2：图片 3：文章',
  `url` varchar(127) NOT NULL DEFAULT '' COMMENT '代理人首页或图片链接',
  `create_time` int(10) NOT NULL,
  `editor_id` int(11) NOT NULL DEFAULT '0' COMMENT '公司小伙伴',
  `start_time` int(10) NOT NULL,
  `end_time` int(10) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL COMMENT '随type变化',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

